import React, { useEffect, useState } from 'react';
import '../params/ListDemandeConge.css';
import { useNavigate } from 'react-router-dom';


function ListDemandeConge() {
    const [demandeConge, setDemandeConge] = useState([]); 
    const navigate = useNavigate();
    useEffect(() => {
        const storedDemandeConge = JSON.parse(localStorage.getItem('demandeconge'));
        if (storedDemandeConge) {
            setDemandeConge(storedDemandeConge);
        }
    }, []);

    const redirectValid = () => {
    }

    const redirectRefuse = () => {

    }

    console.log({demandeConge});
    return (
        <body>
            <h1 style={{ color: "black", fontFamily: "'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif" }}>
                Demande de Congé
            </h1>
            <ul className="olcards"> 
                {demandeConge.map((demande, index) => (
                    <li key={index}>
                        <div className="content"> {}
                            {/* <div className="icon" style={{ fontFamily: "'Courier New', Courier, monospace" }}>ETU2006</div> */}
                            <div className="title"><b>Carte: {demande.matricule}</b></div>
                            <div className="text">
                                <p><b>{demande.typedeconge}</b></p>
                                De <u><b>{demande.date_debut}</b></u> à <u><b>{demande.date_fin}</b></u>
                            </div>
                            {demande.valid === 0 ? (  
                                <div>
                                    <button onClick={redirectValid}>Valider</button>
                                    <button onClick={redirectRefuse}>Refuser</button>
                                </div>
                            ) : (
                                <div>
                                    <button disabled>Valider</button>
                                    <button disabled>Refuser</button>
                                </div>
                            )}
                        </div>
                    </li>
                ))}
            </ul>
        </body>
    );
}

export default ListDemandeConge;
