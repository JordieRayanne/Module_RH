import '../params/Quiz.css';

export default function Quiz(){
    return(
      <>
        
      <div class="formbold-main-wrapper">
    
    <div class="formbold-form-wrapper">
      <img src="your-image-url-here.jpg" />
      <h1>Questionnaire pour critere CV.</h1>
      <form action="https://formbold.com/s/FORM_ID" method="POST" style={{width:100+"%"}}>
        {/* <div class="formbold-input-flex">
          <div>
            <label for="firstname" class="formbold-form-label">
              Nom
            </label>
            <input 
              type="text"
              name="firstname"
              id="firstname"
              placeholder="Jane"
              class="formbold-form-input"
            />
          </div>
          <div>
            <label for="lastname" class="formbold-form-label"> Prénom </label>
            <input
              type="text"
              name="lastname"
              id="lastname"
              placeholder="Cooper"
              class="formbold-form-input"
            />
          </div>
        </div> */}
  
        <div class="formbold-mb-5">
            <label for="qusOne" class="formbold-form-label">
           Diplome minimum:
            </label>
            <select name="diplome" style={{borderRadius: 10 + "px",borderStyle: "dashed",fontFamily: "monospace"}}>
                <option value="1">Master II</option>
                <option value="2">Master I</option>
                <option value="3">Licence</option>
                <option value="4">Bacc</option>
            </select>
            <label for="qusOne" style={{marginLeft: 10 + "px",fontSize:11+"pt"}} > Coeff: <input type="number" name="coefficient" style={{borderColor:"#119e59",fontSize:16+'pt',textAlign:'center',color:"#119e59",borderRadius:10+"px",backgroundColor:'white',paddingTop:10+"px",width: 55+"px"}}/></label>
        </div>
        <div class="formbold-mb-5">
            <label for="qusOne" class="formbold-form-label">
                Expérience:
            </label>
            <input type="text" value="Aucun" disabled style={{width:120+"px"}}/>
            <label for="qusOne" style={{marginLeft: 10 + "px",fontSize:11+"pt"}} > Coeff: <input type="number" name="coefficient" style={{borderColor:"#119e59",fontSize:16+'pt',textAlign:'center',color:"#119e59",borderRadius:10+"px",backgroundColor:'white',paddingTop:10+"px",width: 55+"px"}}/></label>
            <br/>
            <input type="text" value="-3ans" disabled style={{width:120+"px"}}/>
            <label for="qusOne" style={{marginLeft: 10 + "px",fontSize:11+"pt"}} > Coeff: <input type="number" name="coefficient" style={{borderColor:"#119e59",fontSize:16+'pt',textAlign:'center',color:"#119e59",borderRadius:10+"px",backgroundColor:'white',paddingTop:10+"px",width: 55+"px"}}/></label>
            <br/>
            <input type="text" value="+3ans" disabled style={{width:120+"px"}}/>
            <label for="qusOne" style={{marginLeft: 10 + "px",fontSize:11+"pt"}} > Coeff: <input type="number" name="coefficient" style={{borderColor:"#119e59",fontSize:16+'pt',textAlign:'center',color:"#119e59",borderRadius:10+"px",backgroundColor:'white',paddingTop:10+"px",width: 55+"px"}}/></label>
        </div>
        <div class="formbold-mb-5">
            <label for="qusOne" class="formbold-form-label">
          Adresse:
            </label>
            <select name="adresse" style={{borderRadius: 10 + "px",borderStyle: "dashed",fontFamily: "monospace"}}>
                <option value="1">Antananarivo,Andoharanofotsy</option>
                <option value="2">Antananarivo,Tanjombato</option>
            </select>
            <label for="qusOne" style={{marginLeft: 10 + "px",fontSize:11+"pt"}} > Coeff: <input type="number" name="coefficient" style={{borderColor:"#119e59",fontSize:16+'pt',textAlign:'center',color:"#119e59",borderRadius:10+"px",backgroundColor:'white',paddingTop:10+"px",width: 55+"px"}}/></label>
        </div>
        <div class="formbold-mb-5">
            <label for="qusOne" class="formbold-form-label">
          Situation marital:
            </label>
            <select name="situationmarital" style={{borderRadius: 10 + "px",borderStyle: "dashed",fontFamily: "monospace"}}>
                <option value="1">Marié(e)</option>
                <option value="2">Veuf(ve)</option>
                <option value="3">Libre</option>
            </select>
            <label for="qusOne" style={{marginLeft: 10 + "px",fontSize:11+"pt"}} > Coeff: <input type="number" name="coefficient" style={{borderColor:"#119e59",fontSize:16+'pt',textAlign:'center',color:"#119e59",borderRadius:10+"px",backgroundColor:'white',paddingTop:10+"px",width: 55+"px"}}/></label>
        </div>
        <div class="formbold-mb-5">
            <label for="qusOne" class="formbold-form-label">
          Sexe:
            </label>
            <select name="sexe" style={{borderRadius: 10 + "px",borderStyle: "dashed",fontFamily: "monospace"}}>
                <option value="1">Homme</option>
                <option value="2">Femme</option>
            </select>
            <label for="qusOne" style={{marginLeft: 10 + "px",fontSize:11+"pt"}} > Coeff: <input type="number" name="coefficient" style={{borderColor:"#119e59",fontSize:16+'pt',textAlign:'center',color:"#119e59",borderRadius:10+"px",backgroundColor:'white',paddingTop:10+"px",width: 55+"px"}}/></label>
        </div>
        <div class="formbold-mb-5">
            <label for="qusOne" class="formbold-form-label">
          Natonnalité:
            </label>
            <select name="sexe" style={{borderRadius: 10 + "px",borderStyle: "dashed",fontFamily: "monospace"}}>
                <option value="1">Français</option>
                <option value="2">Malagasy</option>
                <option value="3">Anglais</option>
                <option value="4">Allemand</option>
            </select>
            <label for="qusOne" style={{marginLeft: 10 + "px",fontSize:11+"pt"}} > Coeff: <input type="number" name="coefficient" style={{borderColor:"#119e59",fontSize:16+'pt',textAlign:'center',color:"#119e59",borderRadius:10+"px",backgroundColor:'white',paddingTop:10+"px",width: 55+"px"}}/></label>
        </div>
        {/*
        <div class="formbold-mb-5">
          <label for="qusOne" class="formbold-form-label">
            Expérience:
          </label>
   
          <div class="formbold-radio-flex">
            <div class="formbold-radio-group">
              <label class="formbold-radio-label">
                <input
                  class="formbold-input-radio"
                  type="radio"
                  name="qusOne"
                  id="qusOne"
                />
                Option one
                <span class="formbold-radio-checkmark"></span>
              </label>
            </div>
  
            <div class="formbold-radio-group">
              <label class="formbold-radio-label">
                <input
                  class="formbold-input-radio"
                  type="radio"
                  name="qusOne"
                  id="qusOne"
                />
                Option Two
                <span class="formbold-radio-checkmark"></span>
              </label>
            </div>
  
            <div class="formbold-radio-group">
              <label class="formbold-radio-label">
                <input
                  class="formbold-input-radio"
                  type="radio"
                  name="qusOne"
                  id="qusOne"
                />
                Option Three
                <span class="formbold-radio-checkmark"></span>
              </label>
            </div>
  
            <div class="formbold-radio-group">
              <label class="formbold-radio-label">
                <input
                  class="formbold-input-radio"
                  type="radio"
                  name="qusOne"
                  id="qusOne"
                />
                None of them
                <span class="formbold-radio-checkmark"></span>
              </label>
            </div>
          </div>
        </div> */}
  
        <button class="formbold-btn">Submit</button>
      </form>
    </div>
  </div>
  </>
    );
}