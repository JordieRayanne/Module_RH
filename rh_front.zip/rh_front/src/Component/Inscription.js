import { useState } from "react";
import '../params/FormInscription.css'
import { useNavigate } from 'react-router-dom';

function Inscription(){

    const[formValues, setFormValues]=useState({
        nom:'',
        prenom:'',
        date_naissance:'',
        sexe:'',
        cin:'',
        mere:'',
        pere:'',
        situation_matrimonial:'',
        email:'',
        mdp:'',        
    });

    const sexes = ['Homme', 'Femme', 'Autre'];

    const situation_matrimonials= ['celibataire',' mariee',' veuve',' divorcee'];

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormValues({ ...formValues, [name]: value });
    };

    
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault(); // Prevents the default form submission behavior
    
        const gsonData = {
            nom: formValues.nom,
            prenom: formValues.prenom,
            date_naissance: formValues.date_naissance,
            sexe: formValues.sexe,
            cin: formValues.cin,
            mere: formValues.mere,
            pere: formValues.pere,
            situation_matrimonial: formValues.situation_matrimonial,
            email: formValues.email,
            mdp: formValues.mdp,
        };
        console.log(JSON.stringify(gsonData));
    
        fetch('http://localhost:8081/rh_back/InscriptionController', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(gsonData),
            mode: 'cors',
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok: ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            console.log('Reponse de l\'API:', data);
        })
        .catch(error => {
            console.error('Erreur lors de la requête API:', error);
        });

        navigate("/CritereCV");
    };
    
    return(
        <div id="inscription_form">
            <form onSubmit={handleSubmit}>
                <label>Nom: </label>
                <input
                    type="text"
                    name="nom"
                    value={formValues.nom}
                    onChange={handleInputChange}
                    placeholder="Entrez votre nom"     
                    required    
                />
                <label>Prenom: </label>
                <input
                    type="text"
                    name="prenom"
                    value={formValues.prenom}
                    onChange={handleInputChange}
                    placeholder="Entrez votre prenom"     
                    required    
                />
                <label>Date de naissance: </label>
                <input
                    type="date"
                    name="date_naissance"
                    value={formValues.date_naissance}
                    onChange={handleInputChange}
                    placeholder="Entrez votre date_naissance"     
                    required    
                />
                <label>Sexe: </label>
                <select 
                    name="sexe" 
                    value={formValues.sexe} 
                    onChange={handleInputChange}
                    required
                >
                    <option value='' disabled>Sélectionnez votre sexe :</option>
                    { sexes.map((sexe,index) => (
                        <option
                            key={index}
                            value={sexe}
                        >{sexe} 
                        </option>
                    ))}
                </select>

                <label>Numéro de Carte d'Identité Nationale (CIN)</label>
                    <input
                        type="number"
                        placeholder="Entrez votre numéro de CIN"
                        name="cin"
                        value={formValues.cin}
                        onChange={handleInputChange}
                        required
                    />
                <label>Mère: </label>
                <input
                    type="text"
                    name="mere"
                    value={formValues.mere}
                    onChange={handleInputChange}
                    placeholder="Entrez votre mere"     
                    required    
                />
                <label>Père: </label>
                <input
                    type="text"
                    name="pere"
                    value={formValues.pere}
                    onChange={handleInputChange}
                    placeholder="Entrez votre pere"     
                    required    
                />
                <label>situation matrimonial: </label>
                <select 
                    name="situation_matrimonial" 
                    value={formValues.situation_matrimonial} 
                    onChange={handleInputChange}
                    required
                >
                    <option value='' disabled>Sélectionnez votre situation matrimonial :</option>
                    { situation_matrimonials.map((situation_matrimonial,index) => (
                        <option
                            key={index}
                            value={situation_matrimonial}
                        >{situation_matrimonial} 
                        </option>
                    ))}
                </select>
                <label>Email: </label>
                <input
                    type="email"
                    name="email"
                    value={formValues.email}
                    onChange={handleInputChange}
                    placeholder="Entrez votre email"     
                    required    
                />
                <label>Mot de passe: </label>
                <input
                    type="password"
                    name="mdp"
                    value={formValues.mdp}
                    onChange={handleInputChange}
                    placeholder="Entrez votre mot de passe"     
                    required    
                />
                <button variant="primary" type="submit">S'inscrire</button>
            </form>

        </div>
    );

}

export default Inscription;