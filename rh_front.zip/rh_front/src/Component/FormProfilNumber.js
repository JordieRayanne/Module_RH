import { useNavigate } from 'react-router-dom';
import '../params/FormProfilNumber.css';

const { useState , useEffect } = require("react");

function FormProfilNumber(){
  const [employeeValue, setEmployeeValue] = useState(0);
    const[options,setOptions]=useState([]);

    const [formValues, setFormValues] = useState({
      selectedOption: '', // Stocke la valeur sélectionnée dans le menu déroulant
      numberOfProfiles: '', // Stocke le nombre de profils saisi
      idservice:'',
    });

    //getProfil in back ======
    useEffect(() => {
        fetch('http://localhost:8081/rh_back/ProfilController?idservice='+JSON.parse(localStorage.getItem('service_employee')).idService)
          .then(response => response.json())
          .then(data => setOptions(data))
          .catch(error => console.error('Erreur lors de la récupération des données : ', error));
      }, []);
    // --end =======

      const handleSelectChange = event => {
        console.log("Selected Option ID:", event.target.value);
        setFormValues(prevState => ({
          ...prevState,
          selectedOption: event.target.value,
        }));
        console.log(formValues.selectedOption+' tena izy');
      }
      
      const handleNumberInputChange = event => {
        setFormValues(prevState => ({
          ...prevState,
          numberOfProfiles: event.target.value,
        }));
      };
    
    
      const navigate = useNavigate();
      const handleFormSubmit = () => {

        const localStorageServiceVal = localStorage.getItem('service_employee');
        const gsonData = {
          optionId: formValues.selectedOption,
          numberOfProfiles: formValues.numberOfProfiles,
          serviceId: JSON.parse(localStorageServiceVal).idService,
          idvolume: JSON.parse(localStorageServiceVal).idvolume,
        };
        console.log("serviceID: "+formValues.selectedOption);
        console.log("asfasfagg: "+JSON.stringify(gsonData));
        fetch('http://localhost:8081/rh_back/ProfilageController', {
          method:'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body:JSON.stringify(gsonData),
          mode:'cors',

        })
        .then(response => response.json())
        .then(data => {
          console.log('Reponse de l\'API:',data.data);
          // localStorage.setItem('service_employee', JSON.stringify(service_employee));
        })
        .catch(error => {
          console.error('Erreur lors de la requête API :', error);
        });
        setEmployeeValue(employeeValue-formValues.numberOfProfiles);
        console.log(employeeValue-formValues.numberOfProfiles);
        if(String(employeeValue-formValues.numberOfProfiles)==='0'){
          navigate("/");
        }

        // Calculate new employeeValue based on form submission
        const newEmployeeValue = employeeValue - formValues.numberOfProfiles;
        setEmployeeValue(newEmployeeValue);

        // Save the updated value to local storage
        const localStorageValue = localStorage.getItem('service_employee');
        if (localStorageValue) {
          const parsedValue = JSON.parse(localStorageValue);
          parsedValue.employees = newEmployeeValue;
          localStorage.setItem('service_employee', JSON.stringify(parsedValue));
        }
        // console.log(JSON.stringify(gsonData)); // Affiche les données au format JSON dans la console
      };

      useEffect(() => {
        // Get the value from localStorage
        const localStorageValue = localStorage.getItem('service_employee');
        // Update the state with the value from localStorage
        if (localStorageValue) {
          setEmployeeValue(JSON.parse(localStorageValue).employees);
        }
      }, []);
      return (
        <div id="FormProfilNumber"> 
          <h2>Nombre d'employée requis: {employeeValue}</h2>
          <label>Choisissez un profil :</label>
            <select value={formValues.selectedOption} onChange={handleSelectChange}>
                {options.map(option => (
                  <option key={option.id} value={parseInt(option.id, 10)}>
                    {console.log(option.id+"akhgnnnnnnnn")}
                    {option.nom}
                  </option>
                ))}
            </select>

              <label>Nombre: </label>
              <input
                type="number"
                value={formValues.numberOfProfiles}
                onChange={handleNumberInputChange}
                width='50%'
              />

              <button onClick={handleFormSubmit} style={{marginTop:"15px"}}>Valider</button>

        </div>
      );
}

export default FormProfilNumber;
