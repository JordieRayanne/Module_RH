import React from 'react';
import '../params/PDFCard.css'; // Import your custom CSS file

const PdfCard = ({ title,pdf,width,height,displayButton }) => {
  const pdfUrl = process.env.PUBLIC_URL + pdf;
  return (
    <div className="pdf-card" style={{width: width,height:height}}>
      <h3>{title}</h3>
      <iframe
        src={pdfUrl}
        title="PDF Document"
        width={width}
        height={height}
        frameBorder="0"
      ></iframe>
      <a href="#"><button style={{width:100+"px",height:80+"px",display:displayButton}}>POSTULER</button></a>
    </div>
  );
};

export default PdfCard;
