import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import '../params/ContratEssaie.css';

const ContratEssaie = () => {
//======================================= Get idcandidat and idprofil dans la liste CV ======================================================
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const idcandidat = searchParams.get('idcandidat');
    const idprofil = searchParams.get('idprofil');
    console.log("idcandidat "+ idcandidat);
    
//======================================= Get Salaire dans la base de donnée ======================================================
    const [salaires, setSalaires] = useState([]);
  
    useEffect(() => {
      axios.get('http://localhost:8081/rh_back/SalaireController')
        .then(response => {
          setSalaires(response.data);
        })
        .catch(error => {
          console.error('Error fetching salaires:', error);
        });
    }, []);
  

//====================================== Get Avantage dans la base de donnée ======================================================
    const [avantages, setAvantages] = useState([]);

    useEffect(() => {
    axios.get('http://localhost:8081/rh_back/AvantageController')
        .then(response => {
            setAvantages(response.data);
        })
        .catch(error => {
        console.error('Error fetching salaires:', error);
        });
    }, []);

//================================ Get the input value and sent it to ContratEssaieController ========================================        
    const [formData, setFormData] = useState({
        idcandidat: searchParams.get('idcandidat'),
        idprofil: searchParams.get('idprofil'),
        date_debut: '', 
        date_fin: '',
        date_essai: '',
        idsalaire: 0,
        montant_salaire: 0,
        idavantage: 0,
    });
    
    const handleSalaireChange = (event) => {
        console.log("Salaire",event.target.value); 
        setFormData(prevState=>({...prevState,idsalaire:event.target.value}));   
    };

    const handleAvantageChange = (event) => {
        console.log("Avantage",event.target.value); 
        setFormData(prevState=>({...prevState,idavantage:event.target.value})); 
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        const dataToSend = new FormData();
        dataToSend.append("idcandidat",formData.idcandidat);
        dataToSend.append("idprofil",formData.idprofil);
        dataToSend.append("date_debut",formData.date_debut);
        dataToSend.append("date_fin",formData.date_fin);
        dataToSend.append("date_essai",formData.date_essai);
        dataToSend.append("idsalaire",formData.idsalaire);
        dataToSend.append("montant_salaire",formData.montant_salaire);
        dataToSend.append("idavantage",formData.idavantage);
        console.log(JSON.stringify(dataToSend));
        axios.post('http://localhost:8081/rh_back/ContratEssaieController', dataToSend,{
            'Content-Type': 'multipart/form-data',
        })
        .then(response => {
        console.log('Contrat Essaie created:', response.formData);
        })
        .catch(error => {
        console.error('Error creating Contrat Essaie:', error);
        });
    }

//============================================ RETURN ==================================================================
        return (
            <>
            <div class="formbold-main-wrapper">
            <div class="formbold-form-wrapper">
              <h1>Etablissez votre contrat d'essai.</h1>
              <form onSubmit={(event) => handleSubmit(event)} style={{ width: 100 + '%' }}>
                <div class="formbold-mb-5">
                <input 
                    type="hidden" 
                    value={ idcandidat } 
                    name="idcandidat"
                   
                />
                <input 
                    type="hidden" 
                    value={ idprofil }  
                    name="idprofil"
                   
                />
                <label for="qusOne" class="formbold-form-label">
                        Date début :
                    </label>
                    <input 
                        type="date" 
                        style={{width:200+"px"}} 
                        name="date_debut"
                        onChange={(e) => setFormData({ ...formData, date_debut: e.target.value })} 
                    />
                    <label for="qusOne" class="formbold-form-label">
                        Date fin :
                    </label>
                    <input 
                        type="date" 
                        style={{width:200+"px"}} 
                        name="date_fin"
                        onChange={(e) => setFormData({ ...formData, date_fin: e.target.value })} 
                    />
                    <label for="qusOne" class="formbold-form-label">
                        Date essai :
                    </label>
                    <input 
                        type="date" 
                        style={{width:200+"px"}} 
                        name="date_essai"
                        onChange={(e) => setFormData({ ...formData, date_essai: e.target.value })} 
                    />
                    <label for="qusOne" class="formbold-form-label">
                        Type salaire :
                    </label>
                    <select
                        name="idsalaire"
                        style={{ borderRadius: '10px', borderStyle: 'dashed', fontFamily: 'monospace' }}
                        value={formData.selectedSalaire}
                        onChange={handleSalaireChange}
                    >
                    {salaires.map(salaire => (
                        <option value={salaire.id}>
                            {salaire.type}
                        </option>
                    ))}
                    </select>
                    <label for="qusOne" class="formbold-form-label">
                        Montant salaire :
                    </label>
                    <input 
                        type="number" 
                        style={{width:200+"px"}} 
                        name="montant_salaire"
                        onChange={(e) => setFormData({ ...formData, montant_salaire: e.target.value })}
                    />
                    <label for="qusOne" class="formbold-form-label">
                        Avantage :
                    </label>
                    <select
                        name="idavantage"
                        style={{ borderRadius: '10px', borderStyle: 'dashed', fontFamily: 'monospace' }}
                        value={formData.selectedAvantage}
                        onChange={handleAvantageChange}
                    >
                        {avantages.map(avantage => (
                        <option value={avantage.id}>
                            {avantage.type}
                        </option>
                        ))}
                    </select>
                </div>
                <input type="submit" value="Valider"/>
              </form>
            </div>
          </div>
          </>
        );
}

export default ContratEssaie;