export default function DirecteurContent() {
    return (
        <>
            Directeur
        </>
    );
}