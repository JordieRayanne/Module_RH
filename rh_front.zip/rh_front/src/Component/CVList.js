import React from 'react';
import { Link } from 'react-router-dom'; // Import Link from React Router
import '../params/CVList.css';

const CvList = ({ cvList }) => {
  return (
    <div className="cv-list-container">
      <ul className="cv-list">
        {cvList.map((cv) => (
          <li key={cv.id} className="cv-item">
            <div className="cv-details">
              <p>Nom : {cv.nom}</p>
              <p>Profil : {cv.profil}</p>
            </div>
            <div className="cv-note">
              <Link to={`/ContratEssaieView?idcandidat=${cv.idcandidat}&idprofil=${cv.idprofil}`}>
                <button>Contrat</button>
              </Link>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CvList;
