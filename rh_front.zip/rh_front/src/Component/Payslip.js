import Table from "./Table";
import React, { useState , useEffect } from 'react'; // Import useState

function numberToFrenchWords(number) {
    if (number === 0) {
      return "zéro";
    }
  
    const units = ["", "un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf"];
    const teens = ["dix", "onze", "douze", "treize", "quatorze", "quinze", "seize"];
    const tens = ["", "dix", "vingt", "trente", "quarante", "cinquante", "soixante", "soixante-", "quatre-vingt", "quatre-vingt-"];
    const scales = ["", "mille", "million", "milliard"];
  
    function convertChunk(num) {
      if (num === 0) {
        return "";
      } else if (num < 10) {
        return units[num];
      } else if (num < 17) {
        return teens[num - 10];
      } else if (num < 70) {
        const ten = Math.floor(num / 10);
        const unit = num % 10;
        if (unit === 0) {
          return tens[ten];
        } else if (unit === 1 || unit === 11) {
          return tens[ten] + "-et-" + units[unit];
        } else {
          return tens[ten] + "-" + units[unit];
        }
      } else {
        const ten = Math.floor(num / 10);
        const unit = num % 10;
        if (unit === 0) {
          return tens[ten];
        } else if (unit === 1) {
          return tens[ten].slice(0, -1) + " et un";
        } else {
          return tens[ten] + "-" + units[unit];
        }
      }
    }
  
    function numberToFrenchWordsRecursive(num, scale) {
      if (num === 0) {
        return "";
      }
  
      const chunk = num % 1000;
      if (chunk === 0) {
        return numberToFrenchWordsRecursive(Math.floor(num / 1000), scale + 1);
      }
  
      const chunkText = convertChunk(chunk);
      const scaleText = scales[scale];
  
      return chunkText + (scaleText ? " " + scaleText : "");
    }
  
    return numberToFrenchWordsRecursive(number, 0);
  }  
function formatAsMGA(number) {    
    if (isNaN(number)) {
      return 'Invalid Number';
    }
  
    // Convert the number to a string, add commas for thousands separator, and append "MGA"
    return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',') + ' MGA';
  }
  function formatDate(inputDate) {
    const date = new Date(inputDate);
  
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
  
    return `${day}-${month}-${year}`;
  }
  function calculateAge(dateOfBirth) {
    // Split the input date string into day, month, and year components
    const [day, month, year] = dateOfBirth.split('-').map(Number);
  
    // Create a Date object for the date of birth
    const birthDate = new Date(year, month - 1, day); // Month is zero-based, so subtract 1 from the month.
  
    // Create a Date object representing the current date
    const currentDate = new Date();
  
    // Calculate the difference in milliseconds
    const dateDifference = currentDate - birthDate;
  
    // Calculate the number of years, months, and days
    const years = Math.floor(dateDifference / (1000 * 60 * 60 * 24 * 365));
    const months = Math.floor((dateDifference % (1000 * 60 * 60 * 24 * 365)) / (1000 * 60 * 60 * 24 * 30));
    const days = Math.floor((dateDifference % (1000 * 60 * 60 * 24 * 30)) / (1000 * 60 * 60 * 24));
  
    return `${years} ans ${months} mois ${days} jours`;
  }

 function Paylist(){
    
    const [foundPerson,setFoundPerson] = useState();
    useEffect(() => {
        const personnels = JSON.parse(localStorage.getItem("personnels"));
        const fp = personnels.find(person => person.matricule === String(localStorage.getItem("cartefiche")));
        setFoundPerson(fp);
        console.log(fp)
    }, []);
    const columns=[
        {
            Header:'Designation',
            accessor:'designation',
        },
        {
            Header:'Nombre',
            accessor:'nombre',
        },
        {
            Header:'Taux',
            accessor:'taux',
        },
        {
            Header:'Montant',
            accessor:'montant',
        },
    ];
    
    const irsacolumns=[
        {
            Header:'',
            accessor:'designation',
        },
        {
            Header:'',
            accessor:'taux',
        },
        {
            Header:'',
            accessor:'montant',
        },
    ];
    var data = [];
    var irsadata = [];
    if(foundPerson){
         data=[
            {designation:'salaire du 01/10/23 au 30/10/23',nombre:'1mois',taux:formatAsMGA(Math.floor(foundPerson.salaire_brute/30)),montant:formatAsMGA(Math.floor(foundPerson.salaire_brute))},
            {designation:'Absences déductibles',nombre:'',taux:'136144,0',montant:''},
            {designation:'Primes de rendement',nombre:'',taux:'136144,0',montant:''},
            {designation:'Primes d anciennete',nombre:'',taux:'136144,0',montant:''},
            {designation:'Heures supplémentaires majorées de 30%',nombre:'',taux:formatAsMGA(Math.floor(foundPerson.salaire_brute/30)*1.3),montant:''},
            {designation:'Heures supplémentaires majorées de 40%',nombre:'',taux:formatAsMGA(Math.floor(foundPerson.salaire_brute/30)*1.4),montant:''},
            {designation:'Heures supplémentaires majorées de 50%',nombre:'',taux:formatAsMGA(Math.floor(foundPerson.salaire_brute/30)*1.5),montant:''},
            {designation:'Heures supplémentaires majorées de 100%',nombre:'',taux:formatAsMGA(Math.floor(foundPerson.salaire_brute/30)*2),montant:''},
            {designation:'Majoration pour heures de nuit',nombre:'',taux:formatAsMGA(Math.floor(foundPerson.salaire_brute/30)*0.3),montant:''},
            {designation:'Primes diverses',nombre:'',taux:'136144,0',montant:''},
            {designation:'Rappels sur période antérieure',nombre:'',taux:'136144,0',montant:''},
            {designation:'Droits de congés',nombre:'',taux:'136144,0',montant:''},
            {designation:'Droits de préavis',nombre:'',taux:'136144,0',montant:''},
            {designation:'Indemnités de licenciement',nombre:'',taux:'136144,0',montant:''},
            {designation:'',nombre:'',taux:'',montant:''},
            {designation:'',nombre:'',taux:'SALAIRE BRUT',montant:'4083409,09'},
        ];
        
         irsadata=[
            {designation:'retenue CNAPS1 %',taux:'',montant:'20000,00'},
            {designation:'Retenue sanitaire',taux:'',montant:'40834,09'},
            {designation:'Tranche IRSA INF 350 0000',taux:'',montant:''},
            {designation:'Tranche IRSA I DE 350 0001 à 400 000',taux:'5%',montant:'20000,00'},
            {designation:'Tranche IRSA I DE 400 0001 à 500 000',taux:'10%',montant:'20000,00'},
            {designation:'Tranche IRSA I DE 500 001 à 600 000',taux:'15%',montant:'20000,00'},
            {designation:'Tranche IRSA SUP 600 0000',taux:'20%',montant:'20000,00'},
            {designation:'',taux:'',montant:''},
            {designation:'TOTAL IRSA',taux:'',montant:'712015,00'},
            {designation:'',taux:'Total des retenus',montant:'712015,00'},
            {designation:'',taux:'Autres indemnités',montant:''},
        
            {designation:'',taux:'',montant:''},
            {designation:'',taux:'NET A PAYER',montant:'3310560,00'},
        
        ];
    }
    return(
        <div className="paylist">
        {foundPerson ? (
            <>
            <div className="infofiche" style={{display:"inline-flex",width:"100%"}}>
                <div style={{marginLeft:"15px"}}>
                    <h1 style={{ color: "black", fontSize: "14pt", marginTop: "5%" }}>Nom et prénoms: {foundPerson.nom + " " + foundPerson.prenom}</h1>
                    <h1 style={{ color: "black", fontSize: "14pt"}}>Matricule: { foundPerson.matricule }</h1>
                    <h1 style={{ color: "black", fontSize: "14pt"}}>Numéro CNaPS: {"-"}</h1>
                    <h1 style={{ color: "black", fontSize: "14pt"}}>Date d'embauche: { foundPerson.date_embauche }</h1>
                    <h1 style={{ color: "black", fontSize: "14pt"}}>Ancienneté: { calculateAge(foundPerson.date_embauche) }</h1>
                </div>
                <div style={{marginLeft:"41%",textAlign:"start",width:"250px"}}>
                    <h1 style={{ color: "black", fontSize: "14pt", marginTop: "5%" }}>Classification: </h1>
                    <h1 style={{ color: "black", fontSize: "14pt"}}>Salaire de base: </h1>
                    <h1 style={{ color: "black", fontSize: "14pt"}}>Taux journalier: </h1>
                    <h1 style={{ color: "black", fontSize: "14pt"}}>Taux horaires:</h1>
                    <h1 style={{ color: "black", fontSize: "14pt"}}>Indice: </h1>
                </div>
                <div style={{marginLeft:"150px",textAlign:"end",width:"350px"}}>
                    <h1 style={{ color: "black", fontSize: "14pt", marginTop: "5%" }}>{"-"}</h1>
                    <h1 style={{ color: "black", fontSize: "14pt"}}>{ formatAsMGA(foundPerson.salaire_brute) }</h1>
                    <h1 style={{ color: "black", fontSize: "14pt"}}>{formatAsMGA(Math.floor(foundPerson.salaire_brute/30))}</h1>
                    <h1 style={{ color: "black", fontSize: "14pt"}}>{formatAsMGA(Math.floor(foundPerson.salaire_brute/173.33))}</h1>
                    <h1 style={{ color: "black", fontSize: "14pt"}}>{"-"}</h1>
                </div>
            </div>
            <Table columns={columns} data={data} />
            <Table columns={irsacolumns} data={irsadata} />
            <div className="" style={{ border: 'solid 1px', width: '700px', textAlign: 'left',color:"black" }}>
                <p>Avantages en nature:</p>
                <p>Déductions IRSA:</p>
                <p>Montant imposable: 4022575,00</p>
            </div>
            <div className="signature" style={{ textAlign: 'left' }}>
                <p><strong>Mode de paiement: <span style={{ color: 'blue' }}>Virement/chèque</span></strong></p>
                <p><strong>Montant arreté à la somme de: <span style={{ color: 'blue' }}>{numberToFrenchWords(foundPerson.salaire_brute)+" d' Ariary"}</span></strong></p>
                <p><strong>L'employeur</strong></p>
            </div>
            </>
        ) : (
          <>
            <h1 style={{color:"red"}}>Personnel not found ! :(</h1>
            <h3 style={{color:"red"}}>Please check your matricule!</h3>
          </>
        )}
        </div>
    );
 }
 export default Paylist;