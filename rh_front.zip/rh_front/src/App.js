import FormBG from "./Component/FormBG";
import Header from "./Component/Header";
import Nav from "./Component/Nav";
import ProfilageView from "./pages/RH_admin/ProfilageView";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Quiz from "./Component/Quiz";
import FormProfilView from "./pages/RH_admin/FormProfilView";
import FormQuestionView from "./pages/RH_admin/FormQuestionView";
import FormInscriptionView from "./pages/RH_admin/FormInscriptionView";
import AnnonceView from "./pages/RH_admin/AnnonceView";
import ClientHome from "./pages/Candidat/ClientHome";
import CVListView from "./pages/RH_admin/CVListView";
import ContratEssaieView from "./pages/RH_admin/ContratEssaieView";
import FormPersonnelsListView from "./pages/RH_admin/FormPersonnelsListView";
import AnnonceViewClient from "./pages/Candidat/AnnonceViewClient";
import DemandeConge from "./Component/DemandeConge";
import Login from "./Component/Login";
import CongeValide from "./Component/CongeValide";
import IndexContentView from "./pages/RH_admin/IndexContentView";
import EtatdePaie from "./pages/RH_admin/EtatdePaie";
import FichedePaie from "./pages/RH_admin/FichedePaie";
import DemandeCongek from "./Component/DemandeCongek";
import ListDemandeConge from "./Component/ListDemandeConge";
import DirecteurContent from "./Component/DirecteurContent";
import RHContent from "./Component/RHContent";

function App() {
  return (
    <Router>
      <Routes>
          <Route
              path="/AnnonceView"
              element={
                <>
                <div className="d-flex">
                    <div className="col-lg-2 col-md-3 p-0">
                      <Nav />
                    </div>
                    <div className="col-lg-10 col-md-9">
                    <Header />
                    <AnnonceView />
                    </div>
                  </div>
                </>
              }
            />
            <Route
              path="/"
              element={
                <>
                <div className="d-flex">
                    <div className="col-lg-2 col-md-3 p-0">
                      <Nav />
                    </div>
                    <div className="col-lg-10 col-md-9">
                    <Header />
                    <FormBG />
                    </div>
                  </div>
                </>
              }
            />
            <Route
              path="/ProfilageView"
              element={
                <>
                <div className="d-flex">
                    <div className="col-lg-2 col-md-3 p-0">
                      <Nav />
                    </div>
                    <div className="col-lg-10 col-md-9">
                    <Header />
                    <ProfilageView />
                    </div>
                  </div>
                </>
              }
            />
            
            <Route
              path="/FormInscriptionView"
              element={
                <>
                <div className="d-flex">
                    <div className="col-lg-2 col-md-3 p-0">
                      <Nav />
                    </div>
                    <div className="col-lg-10 col-md-9">
                    <Header />
                    <FormInscriptionView />
                    </div>
                  </div>
                </>
              }
            />
            <Route
              path="/FormQuestionView"
              element={
                <>
                <div className="d-flex">
                    <div className="col-lg-2 col-md-3 p-0">
                      <Nav />
                    </div>
                    <div className="col-lg-10 col-md-9">
                    <Header />
                    <FormQuestionView />
                    </div>
                  </div>
                </>
              }
            />
            <Route
              path="/FormProfilView"
              element={
                <>
                <div className="d-flex">
                    <div className="col-lg-2 col-md-3 p-0">
                      <Nav />
                    </div>
                    <div className="col-lg-10 col-md-9">
                    <Header />
                    <FormProfilView />
                    </div>
                  </div>
                </>
              }
            />
            
            <Route
              path="/CritereCV"
              element={
                <>
                <div className="d-flex">
                    <div className="col-lg-2 col-md-3 p-0">
                      <Nav />
                    </div>
                    <div className="col-lg-10 col-md-9">
                    <Header />
                    <Quiz />
                    </div>
                  </div>
                </>
              }
            />
            <Route
              path="/CVListView"
              element={
                <>
                <div className="d-flex">
                    <div className="col-lg-2 col-md-3 p-0">
                      <Nav />
                    </div>
                    <div className="col-lg-10 col-md-9">
                    <Header />
                    <CVListView />
                    </div>
                  </div>
                </>
              }
            />
            <Route
              path="/ContratEssaieView"
              element={
                <>
                <div className="d-flex">
                    <div className="col-lg-2 col-md-3 p-0">
                      <Nav />
                    </div>
                    <div className="col-lg-10 col-md-9">
                    <Header />
                    <ContratEssaieView />
                    </div>
                  </div>
                </>
              }
            />
            <Route
              path="/FormPersonnelsListView"
              element={
                <>
                <div className="d-flex">
                    <div className="col-lg-2 col-md-3 p-0">
                      <Nav />
                    </div>
                    <div className="col-lg-10 col-md-9">
                    <Header />
                    <FormPersonnelsListView />
                    </div>
                  </div>
                </>
              }
            />
            <Route 
              path="/Home" 
              element={
                <>
                  <ClientHome title="Application d'emploiement."/>
                  <AnnonceViewClient />
                </>
              }
             />
             <Route 
              path="/DemandeConge" 
              element={
                <>
                  <ClientHome title="Demande Conge"/>
                  <DemandeCongek />
                </>
              }
             />
             <Route 
              path="/Login" 
              element={
                <>
                  <ClientHome title="Demande Conge"/>
                  <Login />
                </>
              }
             />
             <Route 
              path="/CongeValide" 
              element={
                <>
                  <ClientHome title="Demande Conge"/>
                  <CongeValide />
                </>
              }
             />
             <Route 
              path="/IndexContentView" 
              element={
                <>
                  <IndexContentView />
                </>
              }
             />
             <Route 
              path="/EtatdePaie" 
              element={
                <>
                  <ClientHome title="Etat de paie"/>
                  <EtatdePaie />
                </>
              }
             />
             <Route 
              path="/FichedePaie" 
              element={
                <>
                  <ClientHome title="Fiche de paie"/>
                  <FichedePaie />
                </>
              }
             />
             <Route 
              path="/ListDemandeConge" 
              element={
                <>
                  <ClientHome title="Liste des demandes de conges"/>
                  <ListDemandeConge />
                </>
              }
             />
             <Route 
              path="/RHContent" 
              element={
                <>
                  <RHContent />
                </>
              }
             />
             <Route 
              path="/DirecteurContent" 
              element={
                <>
                  <DirecteurContent />
                </>
              }
             />
        
      </Routes>
    </Router>
  );
}

export default App;
