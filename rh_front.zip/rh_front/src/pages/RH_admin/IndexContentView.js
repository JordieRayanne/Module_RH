import Headerk from '../../Component/Headerk';
import IndexContent from '../../Component/IndexContent';
import { useNavigate } from 'react-router-dom';
import Footer from '../../Component/Footer';


export default function IndexContentView() {
    const navigate = useNavigate;
    const handleDirecteurSubmit = () => {
        navigate('/DirecteurContent');
    };

    const handleRHSubmit = () => {
        navigate('/RHContent');
    };
    return(
        <>
            <Headerk />
            <IndexContent />
            
            <div id={"login_service"} class="login-container">
                <div class="login-screen">
                    <div class="login-screen__content">
                        <h3 style={{marginLeft:"10%",fontSize:"32pt"}}>Directeur de service</h3>
                        <form class="login" >
                            <div class="login__field">
                                <i class="login__icon fas fa-user"></i>
                                <input type="text" class="login__input" placeholder="User name / Email" />
                            </div>
                            <div class="login__field">
                                <i class="login__icon fas fa-lock"></i>
                                <input type="password" class="login__input" placeholder="Password" />
                            </div>
                            <button class="button login__submit" >
                            <a href="/DirecteurContent">
                                    Log In Now
                                    </a>
                                <span class="button__text">
                                    </span>
                                <i class="button__icon fas fa-chevron-right"></i>
                            </button>
                        </form>
                        <div class="social-login">
                            <div class="social-icons">
                                <a href="#" class="social-login__icon fab fa-instagram"></a>
                                <a href="#" class="social-login__icon fab fa-facebook"></a>
                                <a href="#" class="social-login__icon fab fa-twitter"></a>
                            </div>
                        </div>
                    </div>
                    <div class="screen__background">
                        <span class="screen__background__shape screen__background__shape4"></span>
                        <span class="screen__background__shape screen__background__shape3"></span>		
                        <span class="screen__background__shape screen__background__shape2"></span>
                        <span class="screen__background__shape screen__background__shape1"></span>
                    </div>		
                </div>
            </div>
            

            <div id={"login_rh"} class="login-container">
            <div class="login-screen">
                <div class="login-screen__content">
                    <h3 style={{marginLeft:"10%",fontSize:"32pt"}}>Directeur Ressource humaine</h3>
                    <form class="login" >
                        <div class="login__field">
                            <i class="login__icon fas fa-user"></i>
                            <input type="text" class="login__input" placeholder="User name / Email" />
                        </div>
                        <div class="login__field">
                            <i class="login__icon fas fa-lock"></i>
                            <input type="password" class="login__input" placeholder="Password" />
                        </div>
                        <button class="button login__submit" >
                        <a href="/RHContent">
                                Log In Now
                                </a>
                            <span class="button__text">
                                </span>
                            <i class="button__icon fas fa-chevron-right"></i>
                        </button>
                    </form>
                    <div class="social-login">
                        <div class="social-icons">
                            <a href="#" class="social-login__icon fab fa-instagram"></a>
                            <a href="#" class="social-login__icon fab fa-facebook"></a>
                            <a href="#" class="social-login__icon fab fa-twitter"></a>
                        </div>
                    </div>
                </div>
                <div class="screen__background">
                    <span class="screen__background__shape screen__background__shape4"></span>
                    <span class="screen__background__shape screen__background__shape3"></span>		
                    <span class="screen__background__shape screen__background__shape2"></span>
                    <span class="screen__background__shape screen__background__shape1"></span>
                </div>		
            </div>
        </div>
            <Footer />
        </>
    );
}