import FormQuestion from "../../Component/FormQuestion";
const FormQuestionView = () => {
    return(
        <>
            <FormQuestion/>
        </>
    );
}
export default FormQuestionView;