
const ProfilageView = () => {
    return(
        <>
            <h1>Profilage</h1>
        </>
    );
}

export default ProfilageView;