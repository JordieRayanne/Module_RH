import PersonnelsList from "../../Component/PersonnelsList";

const FormPersonnelsListView =()=>{
    return(
        <>
            <PersonnelsList/>
        </>
    );
}
export default FormPersonnelsListView;