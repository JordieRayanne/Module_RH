import Headercli from "../../Component/Headercli";

export default function ClientHome({title}){
    return(
        <>
            <Headercli title={title}/>
        </>
    );
}