import React, { useState , useEffect } from 'react'; // Import useState
import '../params/Headerk.css';
import { json, useNavigate } from 'react-router-dom';
import myImage from '../images/Logo.PNG';





const Headerk = () => {
  // data ====================================================================================================================================================================
  useEffect(() => {
    localStorage.clear(); // Clear local storage when the component mounts (on application load)
  }, []);
  const personnels = [
      {matricule:'P0001',nom:'RAZAKAMANANA',prenom:'Lucie Marie',mot_de_passe:'123',date_naissance:'01-02-1974',sexe:'Femme',date_embauche:'01-05-2019',salaire_brute:'30000000',devise:'Ariary',diplome:'Master',profil:'Directeur de vente'},
      {matricule:'P0002',nom:'RAMANGARIVO',prenom:'Patrick Michel',mot_de_passe: 'abc',date_naissance:'08-09-1969',sexe:'Homme',date_embauche:'05-05-2019',salaire_brute:'15000000',devise:'Ariary',diplome:'License',profil:'Chef de projet'},
      {matricule:'P0003',nom:'RAKOTOARISOA',prenom:'Faly',mot_de_passe:'null',date_naissance:'24-10-1966',sexe:'Homme',date_embauche:'09-05-2019',salaire_brute:'1000000',devise:'Ariary',diplome:'License',profil:'Ressource humaine'},
      {matricule:'P0004',nom:'RASOAMANARIVO',prenom:'Sarah Elodie',mot_de_passe:'null',date_naissance:'17-03-1989',sexe:'Femme',date_embauche:'09-29-2019',salaire_brute:'1000000',devise:'Ariary',diplome:'License',profil:'Consultants te1chnique'},
      {matricule:'P0005',nom:'RABEMANANJARY',prenom:'Manoe',mot_de_passe:'null',date_naissance:'01-02-1996',sexe:'Homme',date_embauche:'18-05-2020',salaire_brute:'1000000',devise:'Ariary',diplome:'License',profil:'Consultants technique'},
      {matricule:'P0006',nom:'RANDRIANANTENAINA',prenom:'Stephane Mickael',mot_de_passe:'null',date_naissance:'31-03-2001',sexe:'Homme',date_embauche:'30-03-2021',salaire_brute:'1000000',devise:'Ariary',diplome:'License',profil:'Consultants technique'},
      {matricule:'P0007',nom:'ANDRIAMARINA',prenom:'Angela',mot_de_passe:'null',date_naissance:'07-06-1998',sexe:'Femme',date_embauche:'20-08-2022',salaire_brute:'1000000',devise:'Ariary',diplome:'License',profil:'Consultants technique'},
  ]

  const conge=[
    {matricule:'P0001',resteconge:'20',restecongespecifique:'10',congematernite:'3',congepaternite:'',absence:'0'},
    {matricule:'P0002',resteconge:'15',restecongespecifique:'10',congematernite:'',congepaternite:'3',absence:'0'},
    {matricule:'P0003',resteconge:'30',restecongespecifique:'10',congematernite:'3',congepaternite:'',absence:'3'},
    {matricule:'P0004',resteconge:'30',restecongespecifique:'10',congematernite:'',congepaternite:'3',absence:'2'},
    {matricule:'P0005',resteconge:'30',restecongespecifique:'10',congematernite:'',congepaternite:'3',absence:'1'},
    {matricule:'P0006',resteconge:'20',restecongespecifique:'10',congematernite:'3',congepaternite:'',absence:'1'},
]

  const navigate = useNavigate();
  const [ficheDePaieValue, setFicheDePaieValue] = useState(''); // Use useState for form value
  
  const handleFicheDePaieSubmit = (event) => {
    event.preventDefault();
    const value = ficheDePaieValue; // Use the state value
    console.log(value);
    localStorage.setItem("cartefiche", value);
    localStorage.setItem("personnels",JSON.stringify(personnels));
    localStorage.setItem('congeData',JSON.stringify(conge));

    navigate("/FichedePaie");
  };

  return (
    <nav className="navbar">
      <img src={myImage} alt="Description de l'image" style={{ marginRight: '550px', width: '120px', height: '50px' }} />
      <ul className="nav-list">
        <li className="nav-item">
          <a href="#">Acceuil</a>
        </li>
        <li className="nav-item">
          <form>
            <input type='text' name='demandeconge' style={{ borderStyle: 'dashed', width: "100px", height: "30px", paddingBottom: "5px", marginRight: "10px" }} />
            <button type='submit' style={{ backgroundColor: "#6ab8ff", width: "80px", height: "30px", fontSize: "12pt", borderRadius: "10px" }}>Demande congé</button>
          </form>
        </li>
        <li className="nav-item">
          <form onSubmit={handleFicheDePaieSubmit}>
            <input
              type='text'
              name='fichedepaie'
              style={{ borderStyle: 'dashed', width: "100px", height: "30px", paddingBottom: "5px", marginRight: "10px" }}
              value={ficheDePaieValue} // Set the value from state
              onChange={(e) => setFicheDePaieValue(e.target.value)} // Update the state
            />
            <button type='submit' style={{ backgroundColor: "#6ab8ff", width: "120px", height: "30px", fontSize: "12pt", borderRadius: "10px" }}>Fiche de paie</button>
          </form>
        </li>
        <li className="nav-item">
          <a href='#'>Fiche de paie</a>
        </li>
        <li className="nav-item">
          <a href='#'>Employées</a>
        </li>
      </ul>
    </nav>
  );
};

export default Headerk;
