import React,{useState} from 'react';
import '../params/DemandeCongek.css';
import { useEffect } from 'react';

function DemandeCongek(){
    const [congeData,setCongeData]=useState([]);

    useEffect(()=>{
        const storedData=localStorage.getItem('congeData');
        if(storedData){
            const parsedData=JSON.parse(storedData);
            setCongeData(parsedData);
        }
    },[]);

    return(
        <div id='demande_conge' class="login-container">

                <div className="conge">
                    {congeData.map((item, index) => (
                    <div key={index}>
                        Matricule: {item.matricule}, Reste Conge: {item.resteconge}, Absence: {item.absence}
                    </div>
                    ))}
                </div>

            <div class="login-screen">
                <div class="login-screen__content">
                    <form class="login">
                        <div class="login__field">
                            <i class="login__icon fas fa-user"></i>
                            <input type="text" class="login__input" placeholder="Date debut" />
                        </div>
                        <div class="login__field">
                            <i class="login__icon fas fa-lock"></i>
                            <input type="text" class="login__input" placeholder="Date fin" />
                        </div>
                        <div class="login__field">
                            <i class="login__icon fas fa-lock"></i>
                            <input type="text" class="login__input" placeholder="Motif" />
                        </div>
                        <label for="cars">Type de congé:</label>
                            <select id="cars" name="cars">
                                <option value="Congé de maternité">Congé de maternité</option>
                                <option value="Congé de paternité">Congé de paternité</option>
                                <option value="Congé sanitaire">Congé sanitaire</option>
                                <option value="Congé personnel">Congé personnel</option>
                            </select>
                        <button class="button login__submit">
                            <span class="button__text">Valider</span>
                            <i class="button__icon fas fa-chevron-right"></i>
                        </button>
                    </form>
                    <div class="social-login">
                        <h3>Demande conge</h3>
                        <div class="social-icons">
                            <a href="#" class="social-login__icon fab fa-instagram"></a>
                            <a href="#" class="social-login__icon fab fa-facebook"></a>
                            <a href="#" class="social-login__icon fab fa-twitter"></a>
                        </div>
                    </div>
                </div>
                <div class="screen__background">
                    <span class="screen__background__shape screen__background__shape4"></span>
                    <span class="screen__background__shape screen__background__shape3"></span>		
                    <span class="screen__background__shape screen__background__shape2"></span>
                    <span class="screen__background__shape screen__background__shape1"></span>
                </div>		
            </div>
        </div>
    );
}

export default DemandeCongek;