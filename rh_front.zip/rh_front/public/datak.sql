------------------------------------ SERVICE -----------------------------------------------------------------------------
insert into service (nom) values ('Informatique');
insert into service (nom) values ('Technique');

------------------------------------ VOLUME ------------------------------------------------------------------------------
insert into volume (nom) values ('Horaire');
insert into volume (nom) values ('Homme jour');

------------------------------------ PROFIL ------------------------------------------------------------------------------
insert into profil (id_service,nom,description) values (1,'Developpeur junior','Devellopeur dynamique et rigoureux.');
insert into profil (id_service,nom,description) values (2,'Technicien','savoir mécanique.');

------------------------------------ DIPLOME -----------------------------------------------------------------------------
insert into diplome (nom,valeur) values ('License',3);
insert into diplome (nom,valeur) values ('Master I',6);
insert into diplome (nom,valeur) values ('Master II',9);
insert into diplome (nom,valeur) values ('Doctorat',15);

------------------------------------ EXPERIENCE -------------------------------------------------------------------------
insert into experience (nom) values ('+ 3 ans');
insert into experience (nom) values ('- 3 ans');
insert into experience (nom) values ('Aucun');

------------------------------------ SITUATION MATRIMONIALE --------------------------------------------------------------
insert into situation_matrimoniale (nom) values ('Veuf(ve)');
insert into situation_matrimoniale (nom) values ('Libre');
insert into situation_matrimoniale (nom) values ('Marié(ée)');

------------------------------------ SEXE --------------------------------------------------------------------------------
insert into sexe (nom) values ('Homme');
insert into sexe (nom) values ('Femme');

----------------------------------- LANGUE -------------------------------------------------------------------------------
insert into langue (nom) values ('Anglais');
insert into langue (nom) values ('Francais');
insert into langue (nom) values ('Malagasy');

----------------------------------- CANDIDAT ------------------------------------------------------------------------------
INSERT INTO candidat (nom, prenom, date_naissance, sexe, CIN, mere, pere, email, mot_de_passe)
VALUES
  ('Doe', 'John', '1990-01-15', 'Masculin', 123456789, 'Jane Doe', 'John Doe Sr.', 'john.doe@email.com', 'password123'),
  ('Smith', 'Alice', '1985-08-22', 'Féminin', 987654321, 'Mary Smith', 'Bob Smith','alice.smith@email.com', 'password456'),
  ('Johnson', 'Bob', '1982-03-10', 'Masculin', 567890123, 'Sue Johnson', 'David Johnson',  'bob.johnson@email.com', 'password789');

----------------------------------- CRITERE CV -----------------------------------------------------------------------------
Insert into critere_CV (idprofil,iddiplome,coeff_diplome,idexperience,coeff_experience,idSM,coeff_SM,idsexe,coeff_sexe,idlangue,coeff_langue)
Values 
(1,1,5,1,10,1,5,1,3,1,10);

---------------------------------- CV CANDIDAT -----------------------------------------------------------------------------
INSERT INTO cv_candidat (idprofil,idcandidat,iddiplome,idexperience,idsm,idsexe,idlangue)
VALUES
(1,1,1,1,1,1,1),
(1,2,2,2,2,2,2),
(1,3,3,3,3,2,3);
