package model;

import dbaccess.PGSQLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Personnels {

    private int id;
    private int id_embauche;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdEmbauche() {
        return id_embauche;
    }

    public void setIdEmbauche(int idEmbauche) {
        this.id_embauche = idEmbauche;
    }
    
    public static int mois_travail(int idpersonnel) throws Exception {
        int mois_travail = 0;
        try (Connection connection = PGSQLConnection.getConnection()) {
            String sql = "SELECT EXTRACT(YEAR FROM AGE(now(), date_embauche)) * 12 + EXTRACT(MONTH FROM AGE(now(), date_embauche)) AS mois_travail " +
                         "FROM personnels_view " +
                         "WHERE id_candidat = ?";  
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, idpersonnel);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        mois_travail = resultSet.getInt("annee_travail");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return mois_travail;
    }
    
    public static double calculateTotalHours(int idPersonnel) {
        String sql = "SELECT SUM(EXTRACT(EPOCH FROM (date_fin - date_debut)) / 3600) AS total_hours " +
                     "FROM absence " +
                     "WHERE id_personnel = ? " +
                     "GROUP BY id_personnel";

        try (Connection connection = PGSQLConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setInt(1, idPersonnel);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getDouble("total_hours");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0.0;
    }
}
