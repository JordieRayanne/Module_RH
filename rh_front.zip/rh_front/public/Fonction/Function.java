//============================ dans la classe demande_conge ==============================================
    public static void updateDemandeCongeEtat(int idPersonnel,Date date_demande) {
        String sql = "UPDATE demande_conge SET etat = 10 WHERE id_personnel = ?";

        try (Connection connection = PGSQLConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setInt(1, idPersonnel);
            preparedStatement.setDate(2, date_demande);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Update successful. Rows affected: " + rowsAffected);
            } else {
                System.out.println("No rows were updated for id_personnel = " + idPersonnel);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
