create table type_conge(
    id serial primary key,
    designation varchar(100)
);

CREATE TABLE "candidat_embauche" (
  "id" serial,
  "id_candidat" int references candidat,
  "id_profil" int references profil,
  "date_embauche" timestamp
  PRIMARY KEY ("id")
);

CREATE TABLE "personnels" (
  "id" serial,
  "id_embauche" int references candidat_embauche,
  PRIMARY KEY ("id")
);

CREATE TABLE "demande_conge" (
  "id" serial,
  "id_personnel" int,
  "date_demande" timestamp,
  "date_debut" timestamp,
  "date_fin" timestamp,
  "etat" int default 0,
  "id_type_conge" int references type_conge,
  PRIMARY KEY ("id")
);
ALTER TABLE "demande_conge" ADD FOREIGN KEY ("id_personnel") REFERENCES "personnels" ("id");

update demande_conge set etat = 10 where id_personnel = 1

select  from demande_conge where id_personnel=1 and etat=10

CREATE TABLE employe_conge(
    id serial primary key,
    id_personnel int references personnels,
    jours_conge datetime,
    date_conge datetime,
    jour_specifique datetime
);

CREATE TABLE "motif_absence" (
  "id" serial,
  "motif" varchar(255),
  PRIMARY KEY ("id")
);

CREATE TABLE "absence" (
  "id" serial,
  "id_personnel" int,
  "id_motif" int,
  "date_debut" timestamp,
  "date_fin" timestamp,
  PRIMARY KEY ("id")
);

------- DATA motif_absence ----------------------------------------
insert into motif_absence (motif) values ('Maladie');
insert into motif_absence (motif) values ('Enterement');
insert into motif_absence (motif) values ('Deces');
insert into motif_absence (motif) values ('Probleme personnel');

-------- DATA absence ---------------------------------------------
insert into absence (id_personnel,id_motif,date_debut,date_fin)
values 
    (1,2,'2021-05-20 08:00:00','2021-05-20 15:00:00'),
    (1,1,'2022-07-15 08:00:00','2022-07-15 18:00:00'),
    (1,3,'2023-03-05 08:00:00','2023-03-05 17:00:00');

--------- DATA conge -----------------------------------------------
insert into type_conge (designation) values ('normal');
insert into type_conge (designation) values ('Conge specifique');
insert into type_conge (designation) values ('Congé de maternite');

--------- DATA personnel ------------------------------------------
insert into personnels (id_embauche) values (1);

--------------------- DATA demande_conge ----------------------------------------------
INSERT INTO "demande_conge" ("id_personnel", "date_demande", "date_debut", "date_fin")
VALUES
  (1, '2023-10-13 08:00:00', '2023-01-02 12:00:00', '2023-01-07 12:00:00'),
  (1, '2023-10-13 08:00:00', '2023-02-12 13:00:00', '2023-02-26 13:00:00'),
  (1, '2023-10-13 08:00:00', '2023-10-11 17:00:00', '2023-10-13 17:00:00');


-------------------- VUE LISTE DEMANDE CONGE ------------------------------------------


SELECT EXTRACT(YEAR FROM age(now(), date_embauche)) AS annee_travail
FROM candidat_embauche
WHERE id_candidat = 1;

SELECT EXTRACT(YEAR FROM AGE(now(), date_embauche)) * 12 + EXTRACT(MONTH FROM AGE(now(), date_embauche)) AS difference_en_mois from candidat_embauche;--ilay 10(mois octobre) mbola tsy tafiditra satria zao mbola voa 9 mois et 14 jours fa tsy mbola 10 mois


