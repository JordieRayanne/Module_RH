import Payroll from "../../Component/Payroll";


export default function EtatdePaie(){
    return(
        <>
         <Payroll />
        </>
    );
}