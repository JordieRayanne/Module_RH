import ContratEssaie from '../../Component/ContratEssaie';

const ContratEssaieView = () => {
return (
    <div>
        <ContratEssaie/>
    </div>
);
}

export default ContratEssaieView;
