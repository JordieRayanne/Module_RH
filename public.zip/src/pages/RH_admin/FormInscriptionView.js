import Inscription from "../../Component/Inscription"

const FormInscriptionView =()=>{
    return(
        <>
        <Inscription/>
        </>
    );
}
export default FormInscriptionView;