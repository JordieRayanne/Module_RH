import Payslip from "../../Component/Payslip";
const { useState , useEffect } = require("react");

export default function FichedePaie(){
    const [cartefiche,setCarteFiche] = useState('none');

    useEffect(() => {
        // Get the value from localStorage
        const cf = localStorage.getItem('cartefiche');
        setCarteFiche(cf);
    }, []);

    return(
        <>
         <Payslip />
        </>
    );
}