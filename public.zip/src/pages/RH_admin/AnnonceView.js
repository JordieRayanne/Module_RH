import React from 'react';
import '../../params/Annonce.css';
import PdfCard from '../../Component/PdfCard';


export default function AnnonceView()  {
      return (
        <>
          <h1>Annonce:</h1>
          <div class="annonce-container">
            <PdfCard title={"Developpeur Junior."} displayButton="none" pdf={"Annonce_Developpeur junior.pdf"} width="900px" height="50vh"/>
            <PdfCard title={"Developpeur Junior."} displayButton="none" pdf={"Annonce_Developpeur junior.pdf"} width="900px" height="50vh"/>
            <PdfCard title={"Developpeur Junior."} displayButton="none" pdf={"Annonce_Developpeur junior.pdf"} width="900px" height="50vh"/>
            <PdfCard title={"Developpeur Junior."} displayButton="none" pdf={"Annonce_Developpeur junior.pdf"} width="900px" height="50vh"/>
            <PdfCard title={"Developpeur Junior."} displayButton="none" pdf={"Annonce_Developpeur junior.pdf"} width="900px" height="50vh"/>
            <PdfCard title={"Developpeur Junior."} displayButton="none" pdf={"Annonce_Developpeur junior.pdf"} width="900px" height="50vh"/>
            <PdfCard title={"Developpeur Junior."} displayButton="none" pdf={"Annonce_Developpeur junior.pdf"} width="900px" height="50vh"/>
          </div>
        </>
    );
};
