import FormBesoin from "../Component/FormBesoin";

const FormBesoinView = () => {
    return(
        <>
            <FormBesoin title="Formulaire d'entree de besoin." value=""/>
        </>
    );
}

export default FormBesoinView;