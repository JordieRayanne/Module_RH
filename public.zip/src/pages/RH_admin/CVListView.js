import React, { useState, useEffect } from 'react';
import CvList from '../../Component/CVList';

const CVListView = () => {
    const [listCandidatEmbauche, setListlistCandidatEmbauche] = useState([]);

    useEffect(() => {
        fetch('http://localhost:8081/rh_back/CandidatEmbaucheViewController')
            .then(response => response.json())
            .then(data => setListlistCandidatEmbauche(data))
            .catch(error => console.error('Erreur lors de la récupération des données : ', error));
    }, []);

    const cvList = listCandidatEmbauche.map(item => ({
        id: item.idce,
        nom: item.nom,
        profil: item.profil,
        idcandidat: item.idCandidat,
        idprofil: item.idProfil,
    }));

    return (
        <div>
            <CvList
                cvList={cvList}
            />
        </div>
    );
};

export default CVListView;
