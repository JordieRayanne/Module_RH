import FormProfilNumber from "../../Component/FormProfilNumber";

const FormProfilView = () => {
    return(
        <>
            <FormProfilNumber/>
        </>
    );
}

export default FormProfilView;