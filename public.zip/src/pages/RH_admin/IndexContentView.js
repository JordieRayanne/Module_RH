import Headerk from '../../Component/Headerk';
import IndexContent from '../../Component/IndexContent';
import Login from '../../Component/Login';
import Footer from '../../Component/Footer';


const IndexContentView = () => {
    return(
        <>
            <Headerk />
            <IndexContent />
            <Login id={"login_service"} title={"Resources Humaines"}/>
            <Login id={"login_rh"} title={"Directeur"}/>
            <Footer />
        </>
    );
}

export default IndexContentView;