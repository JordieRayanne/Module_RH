import '../../params/Annonce.css';
import PdfCard from '../../Component/PdfCard';
import React, { useState, useEffect } from 'react';
import axios from 'axios';


export default function AnnonceViewClient()  {
      // Get all pdf name
        const [pdfFiles, setPdfFiles] = useState([]);

        useEffect(() => {
          axios.get(`http://localhost:8081/rh_back/PDFController`)
            .then(response => {
              console.log('Reponse de l\'API:',JSON.stringify(response.data));
              setPdfFiles(response.data);
            })
            .catch(error => {
              console.error('Error fetching PDF files:', error);
            });
        }, []);

        // get all profilService
        
          const [formValues, setFormValues] = useState({
            selectedProfileservice: '',
          });
          const handleSelectChange = event => {
            console.log("Selected Option ID:", event.target.value);
            setFormValues(prevState => ({
              ...prevState,
              selectedOption: event.target.value,
            }));
            console.log(formValues.selectedOption+' tena izy');
          }
          const[profilServices,setprofilServices]=useState([]);
          useEffect(() => {
            fetch('http://localhost:8081/rh_back/ProfilServiceController')
              .then(response => response.json())
              .then(data => setprofilServices(data))
              .catch(error => console.error('Erreur lors de la récupération des données : ', error));
          }, []);

      return (
        <>
          <h1>Annonce:</h1>
          <select value={formValues.selectedOption} onChange={handleSelectChange}>
                {profilServices.map(option => (
                  <option key={option.id} value={parseInt(option.idProfile, 10)}>
                    {console.log(option.id+"akhgnnnnnnnn")}
                    {option.profileNom}
                  </option>
                ))}
          </select>
          <select>
            <option>Profil 1</option>
            <option>Profil 2</option>
            <option>Profil 3</option>
          </select>
          <select>
            <option>Candidat 1</option>
            <option>Candidat 2</option>
            <option>Candidat 3</option>
          </select>
          <div class="annonce-container">
            {pdfFiles.map(pdfFile => (
              <PdfCard title={pdfFile} displayButton="" pdf={pdfFile} width="900px" height="50vh"/>
            ))}
          </div>
        </>
    );
};
