import React, { useEffect, useState } from 'react';
import '../params/DemandeConge.css';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

export default function DemandeConge(){
    const handleDateChange = (date) => {
        // Handle the selected date
        console.log(date);
      };
    const [listPersonnels, setListPersonnels] = useState([]);
    const [selectedPersonnel, setSelectedPersonnel] = useState('');
    const [selectedCongeType, setSelectedCongeType] = useState('1');
    const [dateDebut, setDateDebut] = useState('');
    const [dateFin, setDateFin] = useState('');
    const [resteconge, setResteConge] = useState();

    useEffect(() => {
        fetch('http://localhost:8081/rh_back/PersonnelsController')
            .then(response => response.json())
            .then(data => setListPersonnels(data))
            .catch(error => console.error('erreur lors de la récupération de listes des personnels',error))
    }, []);

    const handlePersonnel = (event) =>{
        const newval = event.target.value;
        setSelectedPersonnel(newval);
        console.log(selectedPersonnel+" sP");
        const idperso = new FormData();
        idperso.append("idpersonnel",selectedPersonnel);
        console.log(idperso.get('idpersonnel')+" js");
        fetch('http://localhost:8081/rh_back/ResteCongeController', { // Replace YOUR_FORM_SUBMISSION_URL with your actual form submission URL
            method: 'POST',
            body: idperso, // Use the FormData object
        })
        .then(response => {
            console.log(JSON.stringify(response));
        })
        .catch(error => console.error('Form submission error', error));
    }

    const handleSubmit = (event) => {
        event.preventDefault();
        
        // Prepare the data to be submitted
        const data = {
            personnel: selectedPersonnel,
            congeType: selectedCongeType,
            dateDebut: dateDebut,
            dateFin: dateFin
        };
        // Create a new FormData object
        const formData = new FormData();

        // Append the form fields to the FormData object
        formData.append('personnel', selectedPersonnel);
        formData.append('congeType', selectedCongeType);
        formData.append('dateDebut', dateDebut);
        formData.append('dateFin', dateFin);

        // Make a POST request with the FormData
        fetch('http://localhost:8081/rh_back/DemandeCongeController', { // Replace YOUR_FORM_SUBMISSION_URL with your actual form submission URL
            method: 'POST',
            body: formData, // Use the FormData object
        })
        .then(response => {
            // Handle response
            if (response.ok) {
                console.log('Form submitted successfully');
                // Reset form values
                setSelectedPersonnel('');
                setSelectedCongeType('');
                setDateDebut('');
                setDateFin('');

                // setResteConge(response.data);
            } else {
                alert('Form submission failed');
            }
        })
        .catch(error => console.error('Form submission error', error));
    }
    return(
      <>
        
    <div style={{height:"20vh",textAlign:'end'}}>
    </div>
    <div class="formbold-main-wrapper">
    <div class="formbold-form-wrapper">
      <h1>Demande Congé</h1>
      <form onSubmit={handleSubmit} style={{width: 100 + "%"}}>
          <div class="formbold-mb-5">
              <label for="personnel" class="formbold-form-label">
                  Personnel:
              </label>
              <select
                  name="personnel"
                  style={{
                      borderRadius: 10 + "px",
                      borderStyle: "dashed",
                      fontFamily: "monospace"
                  }}
                  value={selectedPersonnel}
                  onChange={handlePersonnel}
              >
                  {listPersonnels.map(personnel => (
                      <option key={personnel.id} value={personnel.id}>
                          {personnel.prenom} {personnel.nom}
                      </option>
                  ))}
              </select>
          </div>
          <div class="formbold-mb-5">
              <label for="congeType" class="formbold-form-label">
                  Type de congé:
              </label>
              <select
                  name="congeType"
                  style={{
                      borderRadius: 10 + "px",
                      borderStyle: "dashed",
                      fontFamily: "monospace"
                  }}
                  value={selectedCongeType}
                  onChange={(e) => setSelectedCongeType(e.target.value)}
              >
                  <option value="1">normal</option>
                  <option value="2">congé specifique</option>
                  <option value="3">congé de maternité</option>
              </select>
          </div>
          <div class="formbold-mb-5">
              <label for="dateDebut" class="formbold-form-label">
                  Date de début:
              </label>
              <input
                  type="date"
                  name="dateDebut"
                  style={{ width: 40 + "%" }}
                  value={dateDebut}
                  onChange={(e) => setDateDebut(e.target.value)}
              />
          </div>
          <div class="formbold-mb-5">
              <label for="dateFin" class="formbold-form-label">
                  Date de fin:
              </label>
              <input
                  type="date"
                  name="dateFin"
                  style={{ width: 40 + "%" }}
                  value={dateFin}
                  onChange={(e) => setDateFin(e.target.value)}
              />
          </div>
          <button type="submit" class="formbold-btn">Submit</button>
      </form>
    </div>
    </div>

        <link href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/datedropper.css" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/datedropper.js"></script>
        <div className="container mt-100">
        <div className="card">
            <div className="row">
            <div className="col-md-4">
                <label>From</label>
                <DatePicker
                selected={""}
                onChange={handleDateChange}
                />
            </div>
            <div className="col-md-4">
                <label>To</label>
                <DatePicker
                selected={""}
                onChange={handleDateChange}
                />
            </div>
            <div className="col-md-4">
                <label>Search</label>
                <button className="btn btn-primary pro-button w-100">
                Add a trip <i className="fa fa-plane ml-2"></i>
                </button>
            </div>
            </div>
        </div>
        </div>
    </>
    );
}