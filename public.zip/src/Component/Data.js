const personnels = [
    {matricule:'P0001',nom:'RAZAKAMANANA',prenom:'Lucie Marie Josephine',date_naissance:'01-02-1974',sexe:'Femme',salaire_brute:'30000000',devise:'Ariary',diplome:'Master',profil:'Directeur de vente'},
    {matricule:'P0002',nom:'RAMANGARIVO',prenom:'Patrick Michel',date_naissance:'08-09-1969',sexe:'Homme',salaire_brute:'15000000',devise:'Ariary',diplome:'License',profil:'Chef de projet'},
    {matricule:'P0003',nom:'RAKOTOARISOA',prenom:'Faly',date_naissance:'24-10-1966',sexe:'Homme',salaire_brute:'1000000',devise:'Ariary',diplome:'License',profil:'Consultants technique'},
    {matricule:'P0004',nom:'RASOAMANARIVO',prenom:'Sarah Elodie',date_naissance:'17-03-1989',sexe:'Femme',salaire_brute:'1000000',devise:'Ariary',diplome:'License',profil:'Consultants te1chnique'},
    {matricule:'P0001',nom:'RABEMANANJARY',prenom:'Manoe',date_naissance:'01-02-1996',sexe:'Homme',salaire_brute:'1000000',devise:'Ariary',diplome:'License',profil:'Consultants technique'},
    {matricule:'P0001',nom:'RABEMANANJARY',prenom:'Manoe',date_naissance:'19-05-2000',sexe:'Homme',salaire_brute:'1000000',devise:'Ariary',diplome:'License',profil:'Consultants technique'},
]

