import React from 'react';
import '../params/IndexContent.css';
import myImage from '../images/teamwork-3213924_1280.jpg';

const IndexContent = () => {
  return (
    <div className="div_body">
        <div className="div_image">
            <img src={myImage} alt="Description de l'image" />
        </div>
        <div className="div_content">
            <b><h1>BIENVENUE DANS NOTRE APPLICATION</h1></b>
            <p>Vous pouvez vous connecter ci-dessus en tant que</p>
            <div className="btn"><a href="#login_service">Vente de service</a></div>
            <div className="btn"><a href="#login_rh">Ressource humaine</a></div>
        </div>
    </div>
  );
};

export default IndexContent;
