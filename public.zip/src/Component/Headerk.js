import React from 'react';
import '../params/Headerk.css';
import { useNavigate } from 'react-router-dom';
import myImage from '../images/Logo.PNG';


const Headerk = () => {
  const Handlefichedepaiesubmit = (event) => {
    event.preventDefault();
    const value= event.target.value;
    console.log(value);
    localStorage.setItem("cartefiche",value);
    const navigate = useNavigate();
    // navigate("/FichedePaie");
}; 

  return (
    <nav className="navbar">
     <img src={myImage} alt="Description de l'image" style={{marginRight:'550px',width:'120px',height:'50px'}}/>
    <ul className="nav-list">
      <li className="nav-item">
        <a href="#" >Acceuil</a>
      </li>
      <li className="nav-item">
        <form>
          <input type='text' name='demandeconge' style={{borderStyle:'dashed',width:"100px",height:"30px",paddingBottom:"5px",marginRight:"10px"}}/>
          <button type='submit' style={{backgroundColor:"#6ab8ff", width:"80px",height:"30px",fontSize:"12pt",borderRadius:"10px"}}>Demande congé</button>
        </form>
      </li>
      <li className="nav-item">
        <form action={Handlefichedepaiesubmit}>
          <input type='text' name='fichedepaie' style={{borderStyle:'dashed', width:"100px",height:"30px",paddingBottom:"5px",marginRight:"10px"}}/>
          <button type='submit' style={{backgroundColor:"#6ab8ff", width:"120px",height:"30px",fontSize:"12pt",borderRadius:"10px"}}>Fiche de paie</button>
        </form>
      </li>
      <li className="nav-item"> 
        <a href='#'>Fiche de paie</a>
      </li>
      <li className="nav-item">
        <a href='#'>Employées</a>
      </li>
    </ul>
  </nav>
  );
};

export default Headerk;
