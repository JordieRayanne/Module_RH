import Table from "./Table";

const columns=[
    {
        Header:'Designation',
        accessor:'designation',
    },
    {
        Header:'Nombre',
        accessor:'nombre',
    },
    {
        Header:'Taux',
        accessor:'taux',
    },
    {
        Header:'Montant',
        accessor:'montant',
    },
];

const irsacolumns=[
    {
        Header:'',
        accessor:'designation',
    },
    {
        Header:'',
        accessor:'taux',
    },
    {
        Header:'',
        accessor:'montant',
    },
];

const data=[
    {designation:'salaire du 01/10/23 au 30/10/23',nombre:'1mois',taux:'136144,0',montant:'483409,00'},
    {designation:'Absences déductibles',nombre:'',taux:'136144,0',montant:''},
    {designation:'Primes de rendement',nombre:'',taux:'136144,0',montant:''},
    {designation:'Primes d anciennete',nombre:'',taux:'136144,0',montant:''},
    {designation:'Heures supplémentaires majorées de 30%',nombre:'',taux:'136144,0',montant:''},
    {designation:'Heures supplémentaires majorées de 40%',nombre:'',taux:'136144,0',montant:''},
    {designation:'Heures supplémentaires majorées de 50%',nombre:'',taux:'136144,0',montant:''},
    {designation:'Heures supplémentaires majorées de 100%',nombre:'',taux:'136144,0',montant:''},
    {designation:'Majoration pour heures de nuit',nombre:'',taux:'136144,0',montant:''},
    {designation:'Primes diverses',nombre:'',taux:'136144,0',montant:''},
    {designation:'Rappels sur période antérieure',nombre:'',taux:'136144,0',montant:''},
    {designation:'Droits de congés',nombre:'',taux:'136144,0',montant:''},
    {designation:'Droits de préavis',nombre:'',taux:'136144,0',montant:''},
    {designation:'Indemnités de licenciement',nombre:'',taux:'136144,0',montant:''},
    {designation:'',nombre:'',taux:'',montant:''},
    {designation:'',nombre:'',taux:'SALAIRE BRUT',montant:'4083409,09'},
];

const irsadata=[
    {designation:'retenue CNAPS1%',taux:'',montant:'20000,00'},
    {designation:'Retenue sanitaire',taux:'',montant:'40834,09'},
    {designation:'Tranche IRSA INF 350 0000',taux:'',montant:''},
    {designation:'Tranche IRSA I DE 350 0001 à 400 000',taux:'5%',montant:'20000,00'},
    {designation:'Tranche IRSA I DE 400 0001 à 500 000',taux:'10%',montant:'20000,00'},
    {designation:'Tranche IRSA I DE 500 001 à 600 000',taux:'15%',montant:'20000,00'},
    {designation:'Tranche IRSA SUP 600 0000',taux:'20%',montant:'20000,00'},
    {designation:'',taux:'',montant:''},
    {designation:'TOTAL IRSA',taux:'',montant:'712015,00'},
    {designation:'',taux:'Total des retenus',montant:'712015,00'},
    {designation:'',taux:'Autres indemnités',montant:''},

    {designation:'',taux:'',montant:''},
    {designation:'',taux:'NET A PAYER',montant:'3310560,00'},

];

 function Paylist(){
    return(
        <div className="paylist">
            <h1>FICHE DE PAIE</h1>
            <Table columns={columns} data={data}/>
            <Table columns={irsacolumns} data={irsadata}/>
            <div className="footer" style={{border:'solid 1px',width:'700px', textAlign: 'left'}}>
                <p>Avantages en nature:</p>
                <p>Déductions IRSA:</p>
                <p>Montant imposable:  4022575,00</p>
            </div>
            <div className="signature" style={{textAlign:'left'}}>
            <p><strong>Mode de paiement: <span style={{ color: 'blue' }}>Virement/chèque</span></strong></p>
            <p><strong>L'employeur</strong></p>
            </div>
        </div>
    );
 }
 export default Paylist;