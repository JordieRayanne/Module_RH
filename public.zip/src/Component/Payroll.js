import Table from "./Table";

const columns=[
    {
        Header:'Date',
        accessor:'date',
    },
    {
        Header:'Nombre',
        accessor:'nombre',
    },
    {
        Header:'N° matr',
        accessor:'matr',
    },
    {
        Header:'N° Cnaps',
        accessor:'cnaps',
    },
    {
        Header:'Nom et Prénom',
        accessor:'nom',
    },
    {
        Header:'Date d embauche',
        accessor:'embauche',
    },
    {
        Header:'Absence du mois',
        accessor:'absence',
    },
    {
        Header:'Catégorie',
        accessor:'categorie',
    },
    {
        Header:'Fonction',
        accessor:'fonction',
    },
    {
        Header:'Salaire de base',
        accessor:'salaire',
    },
    {
        Header:'Retenues sur absence',
        accessor:'retenueabsence',
    },
    {
        Header:'Salaire de base du mois',
        accessor:'salairemois',
    },
    {
        Header:'Indemnite',
        accessor:'indemnite',
    },
    {
        Header:'Rappel',
        accessor:'rappel',
    },
    {
        Header:'RH sup/ Maj',
        accessor:'rh',
    },
    {
        Header:'Salaire brut',
        accessor:'salairebrut',
    },
    {
        Header:'CNaPs 1%',
        accessor:'c1',
    },
    {
        Header:'CNaPs 5%',
        accessor:'c8',
    },
    {
        Header:'OSTIE 1%',
        accessor:'o1',
    },
    {
        Header:'Revenu imposable',
        accessor:'revenu',
    },
    {
        Header:'Impot du',
        accessor:'impot',
    },
    {
        Header:'Enfant',
        accessor:'enfant',
    },
    {
        Header:'Montant',
        accessor:'montant',
    },
    {
        Header:'IGR Net',
        accessor:'igr',
    },
    {
        Header:'Rest retenue',
        accessor:'rest',
    },
    {
        Header:'Total retenues',
        accessor:'total',
    },
    {
        Header:'salaire net',
        accessor:'salairenet',
    },
    {
        Header:'Avance',
        accessor:'avance',
    },
    {
        Header:'Net à payer',
        accessor:'netapayer',
    },
    {
        Header:'Autre indemnité',
        accessor:'autre',
    },
    {
        Header:'Net du mois',
        accessor:'netmois',
    },
];
const data=[
    {date:'01/10/23',nombre:'1',matr:'001',cnaps:'483409,00',nom:'RAKOTOBE',embauche:'483409,00',absence:'483409,00',categorie:'483409,00',fonction:'483409,00',salaire:'483409,00',retenueabsence:'483409,00',salairemois:'483409,00',indemnite:'483409,00',rappel:'483409,00',rh:'483409,00',salairebrut:'483409,00',c1:'483409,00',c8:'483409,00',o1:'483409,00',revenu:'483409,00',impot:'483409,00',enfant:'483409,00',montant:'483409,00',igr:'483409,00',rest:'483409,00',total:'483409,00',salairenet:'483409,00',avance:'483409,00',netapayer:'483409,00',autre:'483409,00',netmois:'483409,00'},
    {date:'01/10/23',nombre:'1',matr:'001',cnaps:'483409,00',nom:'RAKOTOBE',embauche:'483409,00',absence:'483409,00',categorie:'483409,00',fonction:'483409,00',salaire:'483409,00',retenueabsence:'483409,00',salairemois:'483409,00',indemnite:'483409,00',rappel:'483409,00',rh:'483409,00',salairebrut:'483409,00',c1:'483409,00',c8:'483409,00',o1:'483409,00',revenu:'483409,00',impot:'483409,00',enfant:'483409,00',montant:'483409,00',igr:'483409,00',rest:'483409,00',total:'483409,00',salairenet:'483409,00',avance:'483409,00',netapayer:'483409,00',autre:'483409,00',netmois:'483409,00'},
    {date:'01/10/23',nombre:'1',matr:'001',cnaps:'483409,00',nom:'RAKOTOBE',embauche:'483409,00',absence:'483409,00',categorie:'483409,00',fonction:'483409,00',salaire:'483409,00',retenueabsence:'483409,00',salairemois:'483409,00',indemnite:'483409,00',rappel:'483409,00',rh:'483409,00',salairebrut:'483409,00',c1:'483409,00',c8:'483409,00',o1:'483409,00',revenu:'483409,00',impot:'483409,00',enfant:'483409,00',montant:'483409,00',igr:'483409,00',rest:'483409,00',total:'483409,00',salairenet:'483409,00',avance:'483409,00',netapayer:'483409,00',autre:'483409,00',netmois:'483409,00'},
    {date:'',nombre:'',matr:'',cnaps:'',nom:'',embauche:'',absence:'',categorie:'',fonction:'',salaire:'483409,00',retenueabsence:'483409,00',salairemois:'483409,00',indemnite:'483409,00',rappel:'483409,00',rh:'483409,00',salairebrut:'483409,00',c1:'483409,00',c8:'483409,00',o1:'483409,00',revenu:'483409,00',impot:'483409,00',enfant:'483409,00',montant:'483409,00',igr:'483409,00',rest:'483409,00',total:'483409,00',salairenet:'483409,00',avance:'483409,00',netapayer:'483409,00',autre:'483409,00',netmois:'483409,00'},

];

function Payroll(){
    return(
        <div className="paylist">
            <h1>ETAT DE PAIE</h1>
            <Table columns={columns} data={data}/>
        </div>
    );
 }
 export default Payroll;