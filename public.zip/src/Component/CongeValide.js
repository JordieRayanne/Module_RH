import React from 'react';
import '../params/CongeValide.css';

function CongeValide({title="List"}) {
      return (
        <>
            <body>
                <h1 style={{color:"black",fontFamily:"'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif"}}>{title}</h1>
                <ul class="olcards">
                    <li>
                        <div class="content">
                            <div class="icon" style={{fontFamily:"'Courier New', Courier, monospace"} }>ETU2006</div>
                            <div class="title"><b>Rakoto Jean</b></div>
                            <div class="text">
                                <p><b>Congé normal</b></p>
                                De <u><b>2023-10-12</b></u> à <u><b>2023-10-15</b></u>
                            </div>
                            <button>HUHU</button>
                        </div>
                    </li>
                    <li >
                        <div class="content">
                            <div class="icodn">asadsda</div>
                            <div class="icon"></div>
                            <div class="title">Lorem Ipsum</div>
                            <div class="text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium, voluptatem.</div>
                        </div>
                    </li>
                    <li >
                        <div class="content">
                            <div class="icon"></div>
                            <div class="title">Lorem Ipsum</div>
                            <div class="text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium, voluptatem.</div>
                        </div>
                    </li>
                    <li >
                        <div class="content">
                            <div class="icon"></div>
                            <div class="title">Lorem Ipsum</div>
                            <div class="text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium, voluptatem.</div>
                        </div>
                    </li>
                </ul>
            </body>
        </>
      );
};

export default CongeValide;
