import React, { useEffect, useState } from 'react';
import '../params/PersonnelsList.css';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faUser } from '@fortawesome/free-solid-svg-icons';

function PersonnelsList() {
    const [listPersonnels, setListPersonnels] = useState([]);
    const [detailsVisible, setDetailsVisible] = useState(false);
    const [selectedPersonnel, setSelectedPersonnel] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [genderFilter, setGenderFilter] = useState('all'); 

    useEffect(() => {
        fetch('http://localhost:8081/rh_back/PersonnelsController')
            .then(response => response.json())
            .then(data => setListPersonnels(data))
            .catch(error => console.error('erreur lors de la récupération de listes des personnels'))
    }, []);

    const handleDetailsClick = (personnel) => {
        setDetailsVisible(true);
        setSelectedPersonnel(personnel);
    };

    const handleSearch = (event) => {
        setSearchTerm(event.target.value);
    };

    const handleGenderFilterChange = (event) => {
        setGenderFilter(event.target.value);
    };

    const filteredPersonnels = listPersonnels.filter(personnel => {
        const fullName = `${personnel.nom} ${personnel.prenom}`.toLowerCase();
        const isGenderMatch = genderFilter === 'all' || personnel.sexe === genderFilter;
        return fullName.includes(searchTerm.toLowerCase()) && isGenderMatch;
    });

    return (
        <div id='content'>
            <meta charset="UTF-8"></meta>
            <div className="search-bar">
                <input
                    type="text"
                    placeholder="Rechercher un personnel..."
                    value={searchTerm}
                    onChange={handleSearch}
                />
            </div>
            <div className="gender-filter">
                <label htmlFor="gender">Filtrer par sexe:</label>
                <select id="gender" value={genderFilter} onChange={handleGenderFilterChange}>
                    <option value="all">Tous</option>
                    <option value="M">Homme</option>
                    <option value="F">Femme</option>
                </select>
            </div>
            <div className="card-container">
                {filteredPersonnels.map(personnel => (
                    <div className="card" key={personnel.id}>
                        {/* <div className="icon">
                            <FontAwesomeIcon icon={faUser} size="3x" />
                        </div> */}
                        <h2>{personnel.nom}</h2>
                        <h3>{personnel.prenom}</h3>
                        <button onClick={() => handleDetailsClick(personnel)}>Details</button>
                    </div>
                ))}
            </div>

            {detailsVisible && selectedPersonnel && (
                <div className='details'>
                    <h2>{selectedPersonnel.nom} {selectedPersonnel.prenom}</h2>
                    <p>{selectedPersonnel.sexe === 'M' ? 'Homme' : 'Femme'}</p>
                    <p>{selectedPersonnel.date_naissance}</p>
                    <p>{selectedPersonnel.situation_matrimonial}</p>
                    <p>{selectedPersonnel.email}</p>
                </div>
            )}
        </div>
    );
}

export default PersonnelsList;
