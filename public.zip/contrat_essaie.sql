CREATE TABLE "candidat_embauche" (
  "id" serial,
  "id_candidat" int,
  "id_profil" int references profil,
  PRIMARY KEY ("id")
);

INSERT INTO "candidat_embauche" ("id_candidat","id_profil")
VALUES (1,1),
       (2,1),
       (3,1);

CREATE TABLE "salaire" (
  "id" serial,
  "type" varchar(255),
  PRIMARY KEY ("id")
);

INSERT INTO "salaire" ("type")
VALUES ('Brute'),
       ('Net');

CREATE TABLE "avantage" (
  "id" serial,
  "type" varchar(255),
  PRIMARY KEY ("id")
);

INSERT INTO "avantage" ("type")
VALUES ('Assurance santé'),
       ('Congés payés'),
       ('Bonus annuel');

CREATE TABLE "contrat_essaie" (
  "id" serial,
  "id_candidat_embauche" int NOT NULL,
  "date_debut" date,
  "date_fin" date,
  "id_salaire" int,
  "montant_salaire" decimal(10,2),
  "id_profil" int,
  "id_avantage" int,
  "date_essaie" date,
  "etat" int,
  PRIMARY KEY ("id")
);

CREATE VIEW candidat_embauche_view as
SELECT
    candidat_embauche.id as idCE,
    candidat.id as idcandidat,
    candidat.nom as nom,
    candidat.prenom as prenom,
    candidat.cin as cin,
    profil.id as idprofil,
    profil.nom as profil,
    service.id as idservice,
    service.nom as service
FROM 
    candidat_embauche
INNER JOIN
    candidat ON candidat.id = candidat_embauche.id_candidat
INNER JOIN 
    profil ON profil.id = candidat_embauche.id_profil
INNER JOIN
    service ON service.id = profil.idservice